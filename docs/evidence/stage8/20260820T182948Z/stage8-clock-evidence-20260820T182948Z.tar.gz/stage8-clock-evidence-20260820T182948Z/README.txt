D-009 Stage 8 clock decision evidence

Collector version: stage8-clock-evidence-v1
Protocol version:  2.0.0-pre.1
Collection UTC:    20260820T182948Z
Selected CPUs:     0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100,101,102,103

Scope:
- read-only capability and configuration evidence;
- exact repository/protocol binding;
- no clock source, conversion, serialization sequence, or acceptance limit is selected;
- no skew, drift, resolution-distribution, or read-cost qualification is claimed;
- no Stage 8 implementation, pilot, or performance experiment is authorized.

Review collection_issues.tsv first. CRITICAL entries mean the archive cannot be
used as clean protocol-bound evidence. INFO/WARNING entries identify evidence
that was unavailable or commands that failed and must not be silently inferred.

Privacy: this archive contains hostname, CPU, kernel, firmware product, affinity,
repository-state, and kernel-log excerpts. Review it before sharing. It excludes
environment variables, machine-id, DMI UUIDs, and serial-number fields by design.
